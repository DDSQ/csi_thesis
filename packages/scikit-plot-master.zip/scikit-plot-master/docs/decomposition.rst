.. apidocs file containing the API Documentation
.. _decompositiondocs:

Decomposition Module (API Reference)
====================================

.. automodule:: scikitplot.decomposition
   :members: plot_pca_component_variance, plot_pca_2d_projection