.. apidocs file containing the API Documentation
.. _clusterdocs:

Clusterer Module (API Reference)
================================

.. automodule:: scikitplot.cluster
   :members: plot_elbow_curve