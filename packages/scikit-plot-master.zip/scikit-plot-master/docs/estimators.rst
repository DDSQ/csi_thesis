.. apidocs file containing the API Documentation
.. _estimatorssdocs:

Estimators Module (API Reference)
=================================

.. automodule:: scikitplot.estimators
   :members: plot_learning_curve, plot_feature_importances